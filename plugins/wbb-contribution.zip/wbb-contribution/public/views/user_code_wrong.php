<?php get_header(); ?>

<script>document.title = "<?php echo get_option("wbb_contribution_title_user_activation_message"); ?>";</script>

Your code is wrong

<?php get_footer();?>