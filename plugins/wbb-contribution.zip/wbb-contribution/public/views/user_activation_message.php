<?php get_header(); ?>

<h3>
    Do have to activate your user. Look your mail box.
</h3>

<?php get_footer(); ?>