
<label for="first_name">First Name</label>
<input type="text" id="first_name" name="first_name" value="<?php echo $user_last_name; ?>">
<br>
<label for="last_name">Last Name</label>
<input type="text" id="last_name" name="last_name" value="<?php echo $user_first_name; ?>">
<br>
<label for="email">Email</label>
<input type="text" id="email" name="email" value="<?php echo $user_email; ?>">
<br>


