<?php get_header(); ?>
<div>
    <p><?php echo _e ( 'The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.' , 'webberty' ); ?></p>
</div>


<?php get_footer(); ?>