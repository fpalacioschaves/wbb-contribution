<label for="<?php echo $user_meta_key; ?>"><?php echo $user_meta_key; ?></label>
<input type="text" id="<?php echo $user_meta_key; ?>" name="<?php echo $user_meta_key; ?>" value="<?php echo $user_meta_value; ?>">
<br>

