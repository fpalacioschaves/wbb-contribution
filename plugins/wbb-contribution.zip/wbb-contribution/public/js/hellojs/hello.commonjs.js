//
// CommonJS module for browserify
//
if (typeof module === 'object' && module.exports) {
  // CommonJS definition
  module.exports = hello;
}
