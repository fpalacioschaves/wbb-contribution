<?php
/**
 */
?>


<?php /* ------------------------------------------------------------------------------------ */ ?>

<div id="js-accordion-main">
    <h3>User Login & Register</h3>
    <div>
        <?php include __DIR__."/login_tab.php"; ?>
    </div>
    <h3>Import & Export</h3>
    <div>
        <?php include __DIR__."/imp_exp_tab.php"; ?>
    </div>
    <h3>User Panel</h3>
    <div>
        <?php include __DIR__."/user_panel_tab.php"; ?>
    </div>
    <h3>Content module</h3>
    <div>
        <?php include __DIR__."/content_tab.php"; ?>
    </div>
</div>
