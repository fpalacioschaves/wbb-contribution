<tr>
    <td><?php echo $meta_key; ?></td>
    <td>
        <div class='slideThree js-user-meta-checkbox'>	
            <input type='checkbox' <?php echo $metakey; ?> id='<?php echo $meta_key; ?>' name='<?php echo $meta_key; ?>' <?php echo $get_option; ?> />
            <label for='<?php echo $meta_key; ?>'></label>
        </div>
    </td>
</tr>
